public class AprendiendoJava13 {
    //PabloJavier
    public static void main (String[] args) {
        System.out.printf("%-10s %-10s\n", "orange", "naranja");
        System.out.printf("%-10s %-10s\n", "Persian lime", "Limón persa");
        System.out.printf("%-10s %-10s\n", "Pomelo", "Pomelo");
        System.out.printf("%-10s %-10s\n", "Sweet lime", "Limón dulce");
        System.out.printf("%-10s %-10s\n", "Lemon", "Lima");
        System.out.printf("%-10s %-10s\n", "Lime", "Limón");
        System.out.printf("%-10s %-10s\n", "Dates", "Dátiles");
        System.out.printf("%-10s %-10s\n", "Jujube", "Jujube");
        System.out.printf("%-10s %-10s\n", "Peach", "Durazno");
        System.out.printf("%-10s %-10s\n", "Plum", "Ciruela");
    }
}
