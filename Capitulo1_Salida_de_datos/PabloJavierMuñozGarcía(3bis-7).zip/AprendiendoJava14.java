public class AprendiendoJava14 {
    //PabloJavier
    public static void main(String[] args){
        System.out.println("\033[37m┌───────┬────────┬───────────┬────────┬─────────┐");
        System.out.println("│ \033[33mLunes \033[37m│ \033[34mMartes \033[37m│ \033[35mMiercoles \033[37m│ \033[36mJueves \033[37m│\033[32m Viernes \033[37m│");
        System.out.println("├───────┼────────┼───────────┼────────┼─────────┤");
        System.out.println("│  SI   │        │    SI     │        │         │");
        System.out.println("├───────┤   PR   ├───────────┤   PR   │    PR   │");
        System.out.println("│       │        │           │        │         │");
        System.out.println("│  PR   ├────────┤    FOL    ├────────┼─────────┤");
        System.out.println("│       │   LM   │           │   BD   │    BD   │");
        System.out.println("├───────┴────────┴───────────┴────────┴─────────┤");
        System.out.println("│                    RECREO                     │");
        System.out.println("├───────┬────────┬───────────┬────────┬─────────┤");
        System.out.println("│  FOL  │   LM   │           │   BD   │    BD   │");
        System.out.println("├───────┼────────┤ ENTORNOS  ├────────┼─────────┤");
        System.out.println("│       │        │    DE     │        │         │");
        System.out.println("│  BD   │   SI   │DESARROLLO │   SI   │    LM   │");
        System.out.println("│       │        │           │        │         │");
        System.out.println("└───────┴────────┴───────────┴────────┴─────────┘");


    }
}   
